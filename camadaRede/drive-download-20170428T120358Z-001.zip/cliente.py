import socket               # Import socket module
import time
import re
from subprocess import Popen, PIPE
from random import *
# Funcao para descobrir o tamanho do arquivo em bytes
def getSize(fileobject):
    fileobject.seek(0,2)
    size = fileobject.tell()
    return size

s = socket.socket()         # Create a socket object
host = "192.168.42.119"          # IP do Server
port = 8018                 # Reserve a port for your service.

s.connect((host, port))

# Pergunta ao Server o tamanho do quadro
print 'Asking size of TMQ'

# Guardado o valor limite da PDU respondido pelo server
sizeofPDU = int(s.recv(1024))
time.sleep(1)
sizeofChar = 2

#Pega o MAC do servidor e Escreve no arquivo
pid = Popen(["arp", "-a", host], stdout=PIPE)
ms = pid.communicate()[0]
macServer = re.search(r"(([a-f\d]{1,2}\:){5}[a-f\d]{1,2})", ms) 
print macServer.group()

message = open("teste.txt", 'wb')
message.write(macServer.group())
message.close()

#Pega MAC do cliente e Escreve no arquivo
pid = Popen(["arp", "-a"], stdout=PIPE)
mc = pid.communicate()[0]
macClient = re.search(r"(([a-f\d]{1,2}\:){5}[a-f\d]{1,2})", mc) 
print macClient.group()

message = open("teste.txt", 'a')
message.write("\n")
message.write(macClient.group())
message.close()


# Intervalo para o envio de arquivo em bytes
interval = sizeofPDU/sizeofChar
print interval
# Leitura do arquivo em binario
message = open("teste.txt", 'rb')

# Verifica o tamanho do arquivo
fsize = getSize(message)
message.seek(0)

# numero de caracteres no arquivo
number_chars = fsize + 1

# Divisao do arquivo em partes e envio do para servidor
x = 0
while(x <= number_chars-interval):

    col = randint(0,5) #tem 10% de chance de colisao
    
    while(col >= 3):
	print "Ocorreu colisao"
    	time.sleep(3)
	col = randint(0,5)	
    message.seek(x)
    x+=interval
    envio = message.read(interval)
    print envio
    s.send(envio)
    time.sleep(1)

# envio do restante do arquivo
message.seek(x)
if number_chars%interval:
    col = randint(0,5) #tem 10% de chance de colisao
    
    while(col >= 3):
	print "Ocorreu colisao"
    	time.sleep(3)
	col = randint(0,5)
    print message.read(number_chars%interval)	
    s.send(message.read(number_chars%interval))



print "Done Sending"
s.close
