import socket               # Import socket module

s = socket.socket()         # Create a socket object
host = "192.168.42.119" # Get local machine name
port = 8018                # Reserve a port for your service.
s.bind((host, port))        # Bind to the port

f = open('resp','wb')
s.listen(5)                 # Now wait for client connection.
c, addr = s.accept()     # Establish connection with client.

c.send("6")

print 'Got connection from', addr

while(1):
    print "Receiving..."
    l = c.recv(3)
    print (l)
    f.write(l)
    if(len(l) == 0):
        break

print "Done Receiving"
f.write('\n')
c.send('Thank you for connecting')
f.close()
c.close()                # Close the connection
